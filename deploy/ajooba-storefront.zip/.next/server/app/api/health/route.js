var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[externals]__0fgpzedhhntg9._.js")
R.c("server/chunks/[root-of-the-server]__159vwzcztcnp9._.js")
R.c("server/chunks/_102cbuh30s26u._.js")
R.c("server/chunks/apps_storefront__next-internal_server_app_api_health_route_actions_218kgabxmwm3o.js")
R.m(88816)
module.exports=R.m(88816).exports
