var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[externals]__0fgpzedhhntg9._.js")
R.c("server/chunks/1zzd_next_dist_15auysmbpaeh6._.js")
R.c("server/chunks/[root-of-the-server]__159vwzcztcnp9._.js")
R.c("server/chunks/_0r1sa1k--zqhe._.js")
R.c("server/chunks/apps_storefront__next-internal_server_app_robots_txt_route_actions_0yifdedfyoyi9.js")
R.m(64496)
module.exports=R.m(64496).exports
