var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[externals]__0fgpzedhhntg9._.js")
R.c("server/chunks/1zzd_next_dist_15auysmbpaeh6._.js")
R.c("server/chunks/[root-of-the-server]__159vwzcztcnp9._.js")
R.c("server/chunks/_03fbtq8esi-a2._.js")
R.c("server/chunks/044u_storefront__next-internal_server_app_sitemap_xml_route_actions_0jqrkapmurmm-.js")
R.m(16455)
module.exports=R.m(16455).exports
