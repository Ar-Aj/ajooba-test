globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/EwkYKr35Yj-WyM-4yLexb/_buildManifest.js",
    "static/EwkYKr35Yj-WyM-4yLexb/_ssgManifest.js",
    "static/EwkYKr35Yj-WyM-4yLexb/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0w9p3c6p99cdp.js",
    "static/chunks/31h9lncss9_gq.js",
    "static/chunks/2d1knq61xmdjv.js",
    "static/chunks/28564gx_bojy4.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/about/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/account/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/account/addresses/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/account/exchanges/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/account/orders/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/account/orders/[id]/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/account/returns/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/account/wishlist/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/auth/callback/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/cart/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/checkout/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/contact/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/forgot-password/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/login/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/offline/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/privacy/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/products/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/products/[slug]/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/refund-policy/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/register/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/returns/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/search/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/shipping/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    },
    "/terms/page": {
      "otherChunks": [
        "static/chunks/0w9p3c6p99cdp.js",
        "static/chunks/31h9lncss9_gq.js",
        "static/chunks/2d1knq61xmdjv.js",
        "static/chunks/28564gx_bojy4.js"
      ],
      "runtimeModuleIds": [
        49558
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
