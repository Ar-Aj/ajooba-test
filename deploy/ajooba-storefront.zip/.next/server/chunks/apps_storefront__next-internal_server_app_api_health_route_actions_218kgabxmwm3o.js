module.exports=[24403,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_storefront__next-internal_server_app_api_health_route_actions_218kgabxmwm3o.js.map