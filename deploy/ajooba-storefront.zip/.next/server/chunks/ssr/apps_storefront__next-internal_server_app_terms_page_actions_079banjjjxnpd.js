module.exports=[48877,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_storefront__next-internal_server_app_terms_page_actions_079banjjjxnpd.js.map