module.exports=[59262,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_storefront__next-internal_server_app_about_page_actions_1prqksgo8zfyk.js.map