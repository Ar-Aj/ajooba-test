module.exports=[99786,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_storefront__next-internal_server_app_search_page_actions_0wwxmj0zlh6mg.js.map