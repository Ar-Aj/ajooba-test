module.exports=[89194,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_storefront__next-internal_server_app_returns_page_actions_1wad9ynkcytb2.js.map