module.exports=[99025,a=>{"use strict";a.s([])}];

//# sourceMappingURL=0ie5__next-internal_server_app_account_wishlist_page_actions_1yvidlqf7qbn_.js.map