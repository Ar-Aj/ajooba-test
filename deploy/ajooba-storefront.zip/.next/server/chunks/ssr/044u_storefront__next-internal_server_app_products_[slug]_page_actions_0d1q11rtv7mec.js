module.exports=[89760,a=>{"use strict";a.s([])}];

//# sourceMappingURL=044u_storefront__next-internal_server_app_products_%5Bslug%5D_page_actions_0d1q11rtv7mec.js.map