module.exports=[72740,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_storefront__next-internal_server_app_offline_page_actions_1figprrisiu1k.js.map