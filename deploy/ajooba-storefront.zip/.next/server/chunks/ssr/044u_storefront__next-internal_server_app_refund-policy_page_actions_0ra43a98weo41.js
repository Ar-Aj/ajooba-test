module.exports=[4879,a=>{"use strict";a.s([])}];

//# sourceMappingURL=044u_storefront__next-internal_server_app_refund-policy_page_actions_0ra43a98weo41.js.map