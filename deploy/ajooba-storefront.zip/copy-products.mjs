import fs from "node:fs";
for (const candidate of ["repo/public/products", "../repo/public/products", "../../public/products"]) {
  if (fs.existsSync(candidate) && !fs.existsSync("public/products")) {
    fs.cpSync(candidate, "public/products", { recursive: true });
    console.log("[postbuild] Copied product photos from", candidate);
    break;
  }
}