import fs from "node:fs";
for (const candidate of ["repo_v3/public/products", "repo_v2/public/products", "repo/public/products", "../repo_v3/public/products", "../repo_v2/public/products", "../repo/public/products", "../../public/products"]) {
  if (fs.existsSync(candidate) && !fs.existsSync("apps/storefront/public/products")) {
    fs.cpSync(candidate, "apps/storefront/public/products", { recursive: true });
    console.log("[build] Copied product photos from", candidate);
    break;
  }
}