import fs from "node:fs";
for (const candidate of ["repo_v4/deploy/products", "repo_v3/deploy/products", "../repo_v4/deploy/products", "../../public_html/repo_v4/deploy/products", "/home/u894350956/domains/ajoobafootwear.in/public_html/repo_v4/deploy/products", "/home/u894350956/domains/worthy-cornflowerblue-butterfly-35.hostingersite.com/public_html/repo_v4/deploy/products"]) {
  if (fs.existsSync(candidate)) {
    fs.rmSync("public/products", { recursive: true, force: true });
    fs.cpSync(candidate, "public/products", { recursive: true });
    console.log("[build] Copied 770 real binary product JPEGs from", candidate);
    break;
  }
}